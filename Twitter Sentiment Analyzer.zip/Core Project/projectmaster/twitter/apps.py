from django.apps import AppConfig


class TwitterConfig(AppConfig):
    name = 'twitter'
