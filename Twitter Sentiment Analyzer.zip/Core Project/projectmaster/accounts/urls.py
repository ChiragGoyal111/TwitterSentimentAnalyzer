from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.conf.urls import url

urlpatterns = [
    path('accounts/login', auth_views.LoginView.as_view(template_name="login.html"), name='login'),
    path('accounts/confirmation', views.confirmation, name='confirmation'),
    path('accounts/logout', auth_views.LogoutView.as_view(next_page="login"), name='logout'),
    path('accounts/signup', views.signup, name='signup'),
    
]